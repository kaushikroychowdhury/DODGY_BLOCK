﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Score : MonoBehaviour {

    public Text scoreText;
    void Update()
    {
        
        scoreText.text = Time.timeSinceLevelLoad.ToString("0");
      

    }
}
